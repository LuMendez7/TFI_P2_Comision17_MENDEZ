package com.mycompany.tfi_usuariocredencial.service;

import com.mycompany.tfi_usuariocredencial.dao.CredencialDaoJdbc;
import com.mycompany.tfi_usuariocredencial.entities.CredencialAcceso;

import java.util.List;

public class CredencialService implements GenericService<CredencialAcceso> {

    private CredencialDaoJdbc dao;

    public CredencialService() { this.dao = new CredencialDaoJdbc(); }
    public CredencialService(CredencialDaoJdbc dao) { this.dao = dao; }

    @Override
    public CredencialAcceso insertar(CredencialAcceso c) throws Exception {
        // Validaciones simples
        if (c.getHashPassword() == null || c.getHashPassword().isBlank()) {
            throw new IllegalArgumentException("hashPassword es obligatorio");
        }
        return dao.crear(c);
    }

    @Override
    public CredencialAcceso actualizar(CredencialAcceso c) throws Exception {
        if (c.getId() == null) throw new IllegalArgumentException("ID requerido para actualizar");
        return dao.actualizar(c);
    }

    @Override
    public boolean eliminar(Long id) throws Exception {
        return dao.eliminar(id);
    }

    @Override
    public CredencialAcceso getById(Long id) throws Exception {
        return dao.leer(id);
    }

    @Override
    public List<CredencialAcceso> getAll() throws Exception {
        return dao.leerTodos();
    }
}
