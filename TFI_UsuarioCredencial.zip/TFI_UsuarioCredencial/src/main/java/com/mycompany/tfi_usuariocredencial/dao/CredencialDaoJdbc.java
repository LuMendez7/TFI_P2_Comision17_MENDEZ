package com.mycompany.tfi_usuariocredencial.dao;

import com.mycompany.tfi_usuariocredencial.config.DatabaseConnection;
import com.mycompany.tfi_usuariocredencial.entities.CredencialAcceso;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CredencialDaoJdbc implements GenericDao<CredencialAcceso> {

    private Connection externalConn;

    public CredencialDaoJdbc() {}
    public CredencialDaoJdbc(Connection conn) { this.externalConn = conn; }

private Connection getConn() throws SQLException {
    try {
        return externalConn != null
            ? externalConn
            : com.mycompany.tfi_usuariocredencial.config.DatabaseConnection.getConnection();
    } catch (Exception e) {
        throw new SQLException("Error al obtener conexión: " + e.getMessage(), e);
    }
}

    @Override
    public CredencialAcceso crear(CredencialAcceso c) throws Exception {
        String sql = """
            INSERT INTO credencial_acceso 
            (eliminado, hash_password, salt, ultimo_cambio, requiere_reset, usuario_id) 
            VALUES (?, ?, ?, ?, ?, ?)
        """;
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setBoolean(1, c.isEliminado());
            ps.setString(2, c.getHashPassword());
            ps.setString(3, c.getSalt());
            ps.setTimestamp(4, c.getUltimoCambio() == null ? null : Timestamp.valueOf(c.getUltimoCambio()));
            ps.setBoolean(5, c.isRequiereReset());
            if (c.getUsuarioId() == null)
                ps.setNull(6, Types.BIGINT);
            else
                ps.setLong(6, c.getUsuarioId());

            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) c.setId(rs.getLong(1));
            }
            return c;
        }
    }

    @Override
    public CredencialAcceso leer(Long id) throws Exception {
        String sql = """
            SELECT id, eliminado, hash_password, salt, ultimo_cambio, requiere_reset, usuario_id 
            FROM credencial_acceso 
            WHERE id = ? AND eliminado = FALSE
        """;
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    CredencialAcceso c = new CredencialAcceso();
                    c.setId(rs.getLong("id"));
                    c.setEliminado(rs.getBoolean("eliminado"));
                    c.setHashPassword(rs.getString("hash_password"));
                    c.setSalt(rs.getString("salt"));
                    Timestamp ts = rs.getTimestamp("ultimo_cambio");
                    if (ts != null) c.setUltimoCambio(ts.toLocalDateTime());
                    c.setRequiereReset(rs.getBoolean("requiere_reset"));
                    long uid = rs.getLong("usuario_id");
                    if (!rs.wasNull()) c.setUsuarioId(uid);
                    return c;
                }
            }
            return null;
        }
    }

    @Override
    public List<CredencialAcceso> leerTodos() throws Exception {
        String sql = """
            SELECT id, eliminado, hash_password, salt, ultimo_cambio, requiere_reset, usuario_id 
            FROM credencial_acceso 
            WHERE eliminado = FALSE
        """;
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            List<CredencialAcceso> list = new ArrayList<>();
            while (rs.next()) {
                CredencialAcceso c = new CredencialAcceso();
                c.setId(rs.getLong("id"));
                c.setEliminado(rs.getBoolean("eliminado"));
                c.setHashPassword(rs.getString("hash_password"));
                c.setSalt(rs.getString("salt"));
                Timestamp ts = rs.getTimestamp("ultimo_cambio");
                if (ts != null) c.setUltimoCambio(ts.toLocalDateTime());
                c.setRequiereReset(rs.getBoolean("requiere_reset"));
                long uid = rs.getLong("usuario_id");
                if (!rs.wasNull()) c.setUsuarioId(uid);
                list.add(c);
            }
            return list;
        }
    }

    @Override
    public CredencialAcceso actualizar(CredencialAcceso c) throws Exception {
        String sql = """
            UPDATE credencial_acceso 
            SET eliminado = ?, hash_password = ?, salt = ?, ultimo_cambio = ?, requiere_reset = ?, usuario_id = ? 
            WHERE id = ?
        """;
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, c.isEliminado());
            ps.setString(2, c.getHashPassword());
            ps.setString(3, c.getSalt());
            ps.setTimestamp(4, c.getUltimoCambio() == null ? null : Timestamp.valueOf(c.getUltimoCambio()));
            ps.setBoolean(5, c.isRequiereReset());
            if (c.getUsuarioId() == null)
                ps.setNull(6, Types.BIGINT);
            else
                ps.setLong(6, c.getUsuarioId());
            ps.setLong(7, c.getId());
            ps.executeUpdate();
            return c;
        }
    }

    @Override
    public boolean eliminar(Long id) throws Exception {
        String sql = "UPDATE credencial_acceso SET eliminado = TRUE WHERE id = ?";
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // Método extra: leer por usuario_id
    public CredencialAcceso leerPorUsuarioId(Long usuarioId) throws Exception {
        String sql = "SELECT id FROM credencial_acceso WHERE usuario_id = ? AND eliminado = FALSE";
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return leer(rs.getLong("id"));
                }
                return null;
            }
        }
    }
}
