package com.mycompany.tfi_usuariocredencial.dao;

import com.mycompany.tfi_usuariocredencial.config.DatabaseConnection;
import com.mycompany.tfi_usuariocredencial.entities.CredencialAcceso; 

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CredencialDaoJdbc implements GenericDao<CredencialAcceso> {

    private Connection externalConn;

    public CredencialDaoJdbc() {}

    public CredencialDaoJdbc(Connection conn) {
        this.externalConn = conn;
    }

    private Connection getConn() throws Exception {
        return (externalConn != null)
                ? externalConn
                : DatabaseConnection.getConnection();
    }

    private void cerrar(Connection conn) {
        try {
            if (externalConn == null && conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            // log
        }
    }

    @Override
    public CredencialAcceso crear(CredencialAcceso c) throws Exception {
        String sql = """
            INSERT INTO credencial_acceso
            (eliminado, hash_password, salt, ultimo_cambio, requiere_reset, id_usuario)
            VALUES (?, ?, ?, ?, ?, ?)
        """;

        Connection conn = getConn();
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setBoolean(1, c.isEliminado());
            ps.setString(2, c.getHashPassword());
            ps.setString(3, c.getSalt());
            ps.setTimestamp(4, c.getUltimoCambio() == null ? null : Timestamp.valueOf(c.getUltimoCambio()));
            ps.setBoolean(5, c.isRequiereReset());

            if (c.getIdUsuario() == null)
                ps.setNull(6, Types.BIGINT);
            else
                ps.setLong(6, c.getIdUsuario());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) c.setId(rs.getLong(1));
            }

            return c;

        } finally {
            // Se usa la función 'cerrar' que sólo cierra si externalConn es null.
            cerrar(conn); 
        }
    }

    @Override
    public CredencialAcceso leer(Long id) throws Exception {
        String sql = """
            SELECT id, eliminado, hash_password, salt, ultimo_cambio, requiere_reset, id_usuario
            FROM credencial_acceso
            WHERE id = ? AND eliminado = FALSE
        """;

        Connection conn = getConn();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    CredencialAcceso c = new CredencialAcceso();
                    c.setId(rs.getLong("id"));
                    c.setEliminado(rs.getBoolean("eliminado"));
                    c.setHashPassword(rs.getString("hash_password"));
                    c.setSalt(rs.getString("salt"));

                    Timestamp ts = rs.getTimestamp("ultimo_cambio");
                    if (ts != null) c.setUltimoCambio(ts.toLocalDateTime());

                    c.setRequiereReset(rs.getBoolean("requiere_reset"));

                    long uid = rs.getLong("id_usuario");
                    if (!rs.wasNull()) c.setIdUsuario(uid);

                    return c;
                }
            }

            return null;

        } finally {
            cerrar(conn);
        }
    }

    @Override
    public List<CredencialAcceso> leerTodos() throws Exception {
        String sql = """
            SELECT id, eliminado, hash_password, salt, ultimo_cambio, requiere_reset, id_usuario
            FROM credencial_acceso
            WHERE eliminado = FALSE
        """;

        List<CredencialAcceso> list = new ArrayList<>();
        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                CredencialAcceso c = new CredencialAcceso();

                c.setId(rs.getLong("id"));
                c.setEliminado(rs.getBoolean("eliminado"));
                c.setHashPassword(rs.getString("hash_password"));
                c.setSalt(rs.getString("salt"));

                Timestamp ts = rs.getTimestamp("ultimo_cambio");
                if (ts != null) c.setUltimoCambio(ts.toLocalDateTime());

                c.setRequiereReset(rs.getBoolean("requiere_reset"));

                long uid = rs.getLong("id_usuario");
                if (!rs.wasNull()) c.setIdUsuario(uid);

                list.add(c);
            }

            return list;

        } finally {
            cerrar(conn);
        }
    }

    @Override
    public CredencialAcceso actualizar(CredencialAcceso c) throws Exception {
        String sql = """
            UPDATE credencial_acceso
            SET eliminado = ?, hash_password = ?, salt = ?, ultimo_cambio = ?, requiere_reset = ?, id_usuario = ?
            WHERE id = ?
        """;

        Connection conn = getConn();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, c.isEliminado());
            ps.setString(2, c.getHashPassword());
            ps.setString(3, c.getSalt());
            ps.setTimestamp(4, c.getUltimoCambio() == null ? null : Timestamp.valueOf(c.getUltimoCambio()));
            ps.setBoolean(5, c.isRequiereReset());

            if (c.getIdUsuario() == null)
                ps.setNull(6, Types.BIGINT);
            else
                ps.setLong(6, c.getIdUsuario());

            ps.setLong(7, c.getId());

            ps.executeUpdate();
            return c;

        } finally {
            cerrar(conn);
        }
    }

    @Override
    public boolean eliminar(Long id) throws Exception {
        String sql = "UPDATE credencial_acceso SET eliminado = TRUE WHERE id = ?";

        Connection conn = getConn();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            return ps.executeUpdate() > 0;

        } finally {
            cerrar(conn);
        }
    }

    public CredencialAcceso leerPorUsuarioId(Long usuarioId) throws Exception {
        String sql = "SELECT id FROM credencial_acceso WHERE id_usuario = ? AND eliminado = FALSE";

        Connection conn = getConn();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, usuarioId);

            try (ResultSet rs = ps.executeQuery()) {
                // Si encuentras el ID, usas el método leer (que cierra la conexión si no es transaccional)
                if (rs.next()) return leer(rs.getLong("id")); 
            }

            return null;

        } finally {
            cerrar(conn);
        }
    }
}