package com.mycompany.tfi_usuariocredencial.entities;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CredencialAcceso {
    private Long id;
    private boolean eliminado;
    private String hashPassword;
    private String salt;
    private LocalDateTime ultimoCambio;
    private boolean requiereReset;
    private Long idUsuario; // FK real

    public CredencialAcceso() {}

    public CredencialAcceso(Long id, boolean eliminado, String hashPassword,
                             String salt, LocalDateTime ultimoCambio,
                             boolean requiereReset, Long idUsuario) {
        this.id = id;
        this.eliminado = eliminado;
        this.hashPassword = hashPassword;
        this.salt = salt;
        this.ultimoCambio = ultimoCambio;
        this.requiereReset = requiereReset;
        this.idUsuario = idUsuario;
    }

    // getters y setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public boolean isEliminado() { return eliminado; }
    public void setEliminado(boolean eliminado) { this.eliminado = eliminado; }

    public String getHashPassword() { return hashPassword; }
    public void setHashPassword(String hashPassword) { this.hashPassword = hashPassword; }

    public String getSalt() { return salt; }
    public void setSalt(String salt) { this.salt = salt; }

    public LocalDateTime getUltimoCambio() { return ultimoCambio; }
    public void setUltimoCambio(LocalDateTime ultimoCambio) { this.ultimoCambio = ultimoCambio; }

    public boolean isRequiereReset() { return requiereReset; }
    public void setRequiereReset(boolean requiereReset) { this.requiereReset = requiereReset; }

    public Long getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Long idUsuario) { this.idUsuario = idUsuario; }

    @Override
    public String toString() {
        String uc = (ultimoCambio == null)
                ? "null"
                : ultimoCambio.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

        return """
                CredencialAcceso{
                    id=%d,
                    eliminado=%s,
                    hash='%s',
                    salt='%s',
                    ultimoCambio=%s,
                    requiereReset=%s,
                    idUsuario=%s
                }
                """.formatted(
                id, eliminado, hashPassword, salt, uc, requiereReset, idUsuario
        );
    }
}
