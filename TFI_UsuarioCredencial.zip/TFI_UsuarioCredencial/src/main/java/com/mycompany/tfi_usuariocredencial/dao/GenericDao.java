/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tfi_usuariocredencial.dao;

import java.util.List;

public interface GenericDao<T> {
    T crear(T t) throws Exception;
    T leer(Long id) throws Exception;
    List<T> leerTodos() throws Exception;
    T actualizar(T t) throws Exception;
    boolean eliminar(Long id) throws Exception; // baja lógica
}
