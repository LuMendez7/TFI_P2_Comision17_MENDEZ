/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tfi_usuariocredencial;

public class TFI_UsuarioCredencial {
    public static void main(String[] args) {
        System.out.println("✅ Aplicación iniciada correctamente.");

        // Podés poner acá la lógica de prueba inicial:
        // Por ejemplo, conexión a base de datos o un menú simple.
    }
}