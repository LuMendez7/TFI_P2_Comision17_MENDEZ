package com.mycompany.tfi_usuariocredencial.config;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
    private static final Properties props = new Properties();

    static {
        try (InputStream in = DatabaseConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in == null) {
                throw new RuntimeException("⚠️ Archivo db.properties no encontrado en src/main/resources/");
            }
            props.load(in);
            // Cargar el driver JDBC de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (IOException | ClassNotFoundException e) {
            throw new ExceptionInInitializerError("❌ Error inicializando DatabaseConnection: " + e.getMessage());
        }
    }

    /**
     * Devuelve una conexión activa a la base de datos MySQL.
     */
    public static Connection getConnection() throws SQLException {
        String url = props.getProperty("db.url");
        String user = props.getProperty("db.user");
        String pass = props.getProperty("db.password");

        try {
            return DriverManager.getConnection(url, user, pass);
        } catch (SQLException e) {
            throw new SQLException("❌ Error al conectar a la base de datos: " + e.getMessage(), e);
        }
    }
}
