package com.mycompany.tfi_usuariocredencial.main;

import com.mycompany.tfi_usuariocredencial.entities.CredencialAcceso;
import com.mycompany.tfi_usuariocredencial.entities.Usuario;
import com.mycompany.tfi_usuariocredencial.service.UsuarioService;
import com.mycompany.tfi_usuariocredencial.service.CredencialService;
import com.mycompany.tfi_usuariocredencial.util.InputUtil;

import java.time.LocalDateTime;
import java.util.List;

public class AppMenu {

    private static final UsuarioService usuarioService = new UsuarioService();
    private static final CredencialService credencialService = new CredencialService();

    public static void main(String[] args) {
        System.out.println("TFI - Usuario <-> CredencialAcceso - Menú");
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- MENU ---");
            System.out.println("1) Crear Usuario con Credencial");
            System.out.println("2) Listar Usuarios");
            System.out.println("3) Ver Usuario por ID");
            System.out.println("4) Buscar Usuario por username");
            System.out.println("5) Actualizar Usuario (y/o Credencial)");
            System.out.println("6) Eliminar (baja lógica) Usuario");

            System.out.println("---- CRUD CREDENCIAL ----");
            System.out.println("8) Crear Credencial");
            System.out.println("9) Listar Credenciales");
            System.out.println("10) Ver Credencial por ID");
            System.out.println("11) Actualizar Credencial");
            System.out.println("12) Eliminar (baja lógica) Credencial");

            System.out.println("7) Salir");

            int opt = InputUtil.readInt("Elegí opción: ");
            try {
                switch (opt) {
                    case 1 -> crearUsuario();
                    case 2 -> listarUsuarios();
                    case 3 -> verUsuarioPorId();
                    case 4 -> buscarPorUsername();
                    case 5 -> actualizarUsuario();
                    case 6 -> eliminarUsuario();

                    case 8 -> crearCredencial();
                    case 9 -> listarCredenciales();
                    case 10 -> verCredencialPorId();
                    case 11 -> actualizarCredencial();
                    case 12 -> eliminarCredencial();

                    case 7 -> exit = true;
                    default -> System.out.println("Opción inválida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace(System.out);
            }
        }
        System.out.println("Saliendo...");
    }

    private static void crearUsuario() throws Exception {
        System.out.println("Creando Usuario:");
        String username = InputUtil.readLine("Username: ");
        String email = InputUtil.readLine("Email: ");
        boolean activo = InputUtil.readBoolean("Activo?");

        System.out.println("Datos de Credencial:");
        String hash = InputUtil.readLine("HashPassword (simulado): ");
        String salt = InputUtil.readLine("Salt: ");
        boolean requiereReset = InputUtil.readBoolean("Requiere reset?");

        CredencialAcceso cred = new CredencialAcceso();
        cred.setHashPassword(hash);
        cred.setSalt(salt);
        cred.setUltimoCambio(LocalDateTime.now());
        cred.setRequiereReset(requiereReset);

        Usuario u = new Usuario();
        u.setUsername(username);
        u.setEmail(email);
        u.setActivo(activo);
        u.setFechaRegistro(LocalDateTime.now());
        u.setCredencial(cred);

        Usuario creado = usuarioService.insertar(u);
        System.out.println("Usuario creado: " + creado);
    }

    private static void listarUsuarios() throws Exception {
        List<Usuario> list = usuarioService.getAll();
        if (list.isEmpty()) System.out.println("No hay usuarios.");
        for (Usuario u : list) System.out.println(u);
    }

    private static void verUsuarioPorId() throws Exception {
        Long id = InputUtil.readLong("ID usuario: ");
        Usuario u = usuarioService.getById(id);
        if (u == null) System.out.println("No existe usuario con id " + id);
        else {
            System.out.println(u);
            if (u.getCredencial() != null) System.out.println("Credencial: " + u.getCredencial());
        }
    }

    private static void buscarPorUsername() throws Exception {
        String username = InputUtil.readLine("Username a buscar: ");
        Usuario u = usuarioService.buscarPorUsername(username);
        if (u == null) System.out.println("No encontrado.");
        else System.out.println(u);
    }

    private static void actualizarUsuario() throws Exception {
        Long id = InputUtil.readLong("ID usuario a actualizar: ");
        Usuario u = usuarioService.getById(id);
        if (u == null) { System.out.println("No existe."); return; }

        String newEmail = InputUtil.readLine("Nuevo email (enter para mantener '" + u.getEmail() + "'): ");
        if (!newEmail.isBlank()) u.setEmail(newEmail);

        boolean nuevoActivo = InputUtil.readBoolean("Activo?");
        u.setActivo(nuevoActivo);

        boolean cambiarCred = InputUtil.readBoolean("Actualizar credencial?");
        if (cambiarCred) {
            CredencialAcceso c = u.getCredencial();
            if (c == null) {
                System.out.println("No existe credencial asociada.");
            } else {
                String newHash = InputUtil.readLine("Nuevo hash (enter para mantener): ");
                if (!newHash.isBlank()) c.setHashPassword(newHash);
                String newSalt = InputUtil.readLine("Nuevo salt (enter para mantener): ");
                if (!newSalt.isBlank()) c.setSalt(newSalt);

                c.setUltimoCambio(LocalDateTime.now());
                u.setCredencial(c);
            }
        }

        usuarioService.actualizar(u);
        System.out.println("Usuario actualizado.");
    }

    private static void eliminarUsuario() throws Exception {
        Long id = InputUtil.readLong("ID usuario a eliminar (baja lógica): ");
        boolean ok = usuarioService.eliminar(id);
        System.out.println(ok ? "Usuario dado de baja lógicamente." : "No se pudo dar de baja.");
    }

    private static void crearCredencial() throws Exception {
        System.out.println("Creando Credencial SUELTA (opcionalmente asociada a usuario):");

        Long usuarioId = InputUtil.readLong("ID usuario asociado (0 para NULL): ");
        if (usuarioId == 0) usuarioId = null;

        String hash = InputUtil.readLine("HashPassword (simulado): ");
        String salt = InputUtil.readLine("Salt: ");
        boolean reqReset = InputUtil.readBoolean("Requiere reset?");

        CredencialAcceso c = new CredencialAcceso();
        c.setHashPassword(hash);
        c.setSalt(salt);
        c.setUltimoCambio(LocalDateTime.now());
        c.setRequiereReset(reqReset);
        c.setUsuarioId(usuarioId);

        CredencialAcceso creado = credencialService.insertar(c);
        System.out.println("Credencial creada: " + creado);
    }

    private static void listarCredenciales() throws Exception {
        List<CredencialAcceso> list = credencialService.getAll();
        if (list.isEmpty()) System.out.println("No hay credenciales.");
        for (CredencialAcceso c : list) System.out.println(c);
    }

    private static void verCredencialPorId() throws Exception {
        Long id = InputUtil.readLong("ID credencial: ");
        CredencialAcceso c = credencialService.getById(id);
        if (c == null) System.out.println("No existe credencial con ID " + id);
        else System.out.println(c);
    }

    private static void actualizarCredencial() throws Exception {
        Long id = InputUtil.readLong("ID credencial a actualizar: ");
        CredencialAcceso c = credencialService.getById(id);

        if (c == null) { System.out.println("No existe."); return; }

        String newHash = InputUtil.readLine("Nuevo hash (enter para mantener): ");
        if (!newHash.isBlank()) c.setHashPassword(newHash);

        String newSalt = InputUtil.readLine("Nuevo salt (enter para mantener): ");
        if (!newSalt.isBlank()) c.setSalt(newSalt);

        boolean reqReset = InputUtil.readBoolean("Requiere reset?");
        c.setRequiereReset(reqReset);

        Long newUserId = InputUtil.readLong("Nuevo usuarioId (0 para mantener): ");
        if (newUserId != 0) c.setUsuarioId(newUserId);

        c.setUltimoCambio(LocalDateTime.now());

        credencialService.actualizar(c);
        System.out.println("Credencial actualizada.");
    }

    private static void eliminarCredencial() throws Exception {
        Long id = InputUtil.readLong("ID credencial a eliminar (baja lógica): ");
        boolean ok = credencialService.eliminar(id);
        System.out.println(ok ? "Credencial dada de baja." : "No se pudo realizar la baja.");
    }
}