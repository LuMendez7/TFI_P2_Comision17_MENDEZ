/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tfi_usuariocredencial.util;

import java.util.Scanner;

public class InputUtil {
    private static final Scanner sc = new Scanner(System.in);

    public static String readLine(String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }

    public static int readInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String s = sc.nextLine();
                return Integer.parseInt(s.trim());
            } catch (Exception e) {
                System.out.println("Entrada inválida. Ingresá un número entero.");
            }
        }
    }

    public static Long readLong(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String s = sc.nextLine();
                return Long.parseLong(s.trim());
            } catch (Exception e) {
                System.out.println("Entrada inválida. Ingresá un número entero largo.");
            }
        }
    }

    public static boolean readBoolean(String prompt) {
        while (true) {
            System.out.print(prompt + " (S/N): ");
            String s = sc.nextLine().trim().toLowerCase();
            if (s.equals("s") || s.equals("si") || s.equals("y")) return true;
            if (s.equals("n") || s.equals("no")) return false;
            System.out.println("Ingresá S o N.");
        }
    }
}
