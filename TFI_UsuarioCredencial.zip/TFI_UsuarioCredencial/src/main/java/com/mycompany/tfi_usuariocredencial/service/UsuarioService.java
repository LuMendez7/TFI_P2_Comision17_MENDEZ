package com.mycompany.tfi_usuariocredencial.service;

import com.mycompany.tfi_usuariocredencial.config.DatabaseConnection;
import com.mycompany.tfi_usuariocredencial.dao.CredencialDaoJdbc;
import com.mycompany.tfi_usuariocredencial.dao.UsuarioDaoJdbc;
import com.mycompany.tfi_usuariocredencial.entities.CredencialAcceso;
import com.mycompany.tfi_usuariocredencial.entities.Usuario;

import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.List;

public class UsuarioService implements GenericService<Usuario> {

    private UsuarioDaoJdbc usuarioDao;
    private CredencialDaoJdbc credDao;

    public UsuarioService() {
        this.usuarioDao = new UsuarioDaoJdbc();
        this.credDao = new CredencialDaoJdbc();
    }

    // insertar: crear credencial -> crear usuario (transaccional) y asociar id_usuario en credencial
    @Override
    public Usuario insertar(Usuario usuario) throws Exception {
        // validaciones
        if (usuario.getUsername() == null || usuario.getUsername().isBlank()) {
            throw new IllegalArgumentException("username requerido");
        }
        if (usuario.getEmail() == null || usuario.getEmail().isBlank()) {
            throw new IllegalArgumentException("email requerido");
        }
        if (usuario.getCredencial() == null) {
            throw new IllegalArgumentException("credencial requerida");
        }

        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // crear credencial con connection compartida
            CredencialDaoJdbc credDaoTx = new CredencialDaoJdbc(conn);
            CredencialAcceso cred = usuario.getCredencial();
            cred = credDaoTx.crear(cred);

            // crear usuario y asignar fechaRegistro
            usuario.setFechaRegistro(LocalDateTime.now());
            UsuarioDaoJdbc userDaoTx = new UsuarioDaoJdbc(conn);
            usuario = userDaoTx.crear(usuario);

            // asociar id_usuario en credencial y actualizar
            cred.setIdUsuario(usuario.getId());
            credDaoTx.actualizar(cred);

            conn.commit();
            return usuario;
        } catch (Exception ex) {
            if (conn != null) conn.rollback();
            throw ex;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    @Override
    public Usuario actualizar(Usuario usuario) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            UsuarioDaoJdbc userDaoTx = new UsuarioDaoJdbc(conn);
            CredencialDaoJdbc credDaoTx = new CredencialDaoJdbc(conn);

            if (usuario.getCredencial() != null) {
                CredencialAcceso c = usuario.getCredencial();
                if (c.getId() == null)
                    throw new IllegalArgumentException("Credencial existe pero falta id");
                credDaoTx.actualizar(c);
            }

            userDaoTx.actualizar(usuario);

            conn.commit();
            return usuario;

        } catch (Exception ex) {
            if (conn != null) conn.rollback();
            throw ex;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    @Override
    public boolean eliminar(Long id) throws Exception {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            UsuarioDaoJdbc userDaoTx = new UsuarioDaoJdbc(conn);
            CredencialDaoJdbc credDaoTx = new CredencialDaoJdbc(conn);

            var cred = credDaoTx.leerPorUsuarioId(id);
            if (cred != null) credDaoTx.eliminar(cred.getId());

            boolean ok = userDaoTx.eliminar(id);

            conn.commit();
            return ok;

        } catch (Exception ex) {
            if (conn != null) conn.rollback();
            throw ex;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    @Override
    public Usuario getById(Long id) throws Exception {
        Usuario u = new UsuarioDaoJdbc().leer(id);
        if (u != null) {
            var cred = new CredencialDaoJdbc().leerPorUsuarioId(id);
            u.setCredencial(cred);
        }
        return u;
    }

    @Override
    public List<Usuario> getAll() throws Exception {
        return new UsuarioDaoJdbc().leerTodos();
    }

    public Usuario buscarPorUsername(String username) throws Exception {
        Usuario u = new UsuarioDaoJdbc().leerPorUsername(username);
        if (u != null) u.setCredencial(new CredencialDaoJdbc().leerPorUsuarioId(u.getId()));
        return u;
    }

    public Usuario buscarPorEmail(String email) throws Exception {
        Usuario u = new UsuarioDaoJdbc().leerPorEmail(email);
        if (u != null) u.setCredencial(new CredencialDaoJdbc().leerPorUsuarioId(u.getId()));
        return u;
    }
}
