package com.mycompany.tfi_usuariocredencial.dao;

import com.mycompany.tfi_usuariocredencial.config.DatabaseConnection;
import com.mycompany.tfi_usuariocredencial.entities.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDaoJdbc implements GenericDao<Usuario> {

    private Connection externalConn;

    public UsuarioDaoJdbc() {}

    public UsuarioDaoJdbc(Connection conn) {
        this.externalConn = conn;
    }

    private Connection getConn() throws Exception {
        return (externalConn != null)
                ? externalConn
                : DatabaseConnection.getConnection();
    }

    @Override
    public Usuario crear(Usuario u) throws Exception {
        String sql = """
            INSERT INTO usuario (username, email, activo, eliminado, fecha_registro)
            VALUES (?, ?, ?, FALSE, NOW())
        """;

        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, u.getUsername());
            ps.setString(2, u.getEmail());
            ps.setBoolean(3, u.isActivo());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) u.setId(rs.getLong(1));
            }

            return u;

        } catch (SQLException e) {
            throw new Exception("Error al crear usuario: " + e.getMessage(), e);
        }
    }

    @Override
    public Usuario leer(Long id) throws Exception {
        String sql = """
            SELECT id, username, email, activo
            FROM usuario
            WHERE id = ? AND eliminado = FALSE
        """;

        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId(rs.getLong("id"));
                    u.setUsername(rs.getString("username"));
                    u.setEmail(rs.getString("email"));
                    u.setActivo(rs.getBoolean("activo"));
                    return u;
                }
            }

            return null;
        }
    }

    @Override
    public List<Usuario> leerTodos() throws Exception {
        String sql = """
            SELECT id, username, email, activo
            FROM usuario
            WHERE eliminado = FALSE
        """;

        List<Usuario> lista = new ArrayList<>();
        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getLong("id"));
                u.setUsername(rs.getString("username"));
                u.setEmail(rs.getString("email"));
                u.setActivo(rs.getBoolean("activo"));
                lista.add(u);
            }

            return lista;
        }
    }

    @Override
    public Usuario actualizar(Usuario u) throws Exception {
        String sql = """
            UPDATE usuario
            SET username = ?, email = ?, activo = ?
            WHERE id = ?
        """;

        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getUsername());
            ps.setString(2, u.getEmail());
            ps.setBoolean(3, u.isActivo());
            ps.setLong(4, u.getId());

            ps.executeUpdate();
            return u;
        }
    }

    @Override
    public boolean eliminar(Long id) throws Exception {
        String sql = "UPDATE usuario SET eliminado = TRUE WHERE id = ?";

        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // Métodos extra

    public Usuario leerPorUsername(String username) throws Exception {
        String sql = """
            SELECT id, username, email, activo
            FROM usuario
            WHERE username = ? AND eliminado = FALSE
        """;

        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId(rs.getLong("id"));
                    u.setUsername(rs.getString("username"));
                    u.setEmail(rs.getString("email"));
                    u.setActivo(rs.getBoolean("activo"));
                    return u;
                }
            }

            return null;
        }
    }

    public Usuario leerPorEmail(String email) throws Exception {
        String sql = """
            SELECT id, username, email, activo
            FROM usuario
            WHERE email = ? AND eliminado = FALSE
        """;

        Connection conn = getConn();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId(rs.getLong("id"));
                    u.setUsername(rs.getString("username"));
                    u.setEmail(rs.getString("email"));
                    u.setActivo(rs.getBoolean("activo"));
                    return u;
                }
            }

            return null;
        }
    }
}
