package com.mycompany.tfi_usuariocredencial.dao;

import com.mycompany.tfi_usuariocredencial.config.DatabaseConnection;
import com.mycompany.tfi_usuariocredencial.entities.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDaoJdbc implements GenericDao<Usuario> {

    private Connection externalConn;

    public UsuarioDaoJdbc() {}
    public UsuarioDaoJdbc(Connection conn) { this.externalConn = conn; }

private Connection getConn() throws SQLException {
    try {
        return externalConn != null
            ? externalConn
            : com.mycompany.tfi_usuariocredencial.config.DatabaseConnection.getConnection();
    } catch (Exception e) {
        throw new SQLException("Error al obtener conexión: " + e.getMessage(), e);
    }
}

    @Override
    public Usuario crear(Usuario u) throws Exception {
        String sql = """
            INSERT INTO usuario 
            (eliminado, username, email, activo, fecha_registro) 
            VALUES (?, ?, ?, ?, ?)
        """;

        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setBoolean(1, u.isEliminado());
            ps.setString(2, u.getUsername());
            ps.setString(3, u.getEmail());
            ps.setBoolean(4, u.isActivo());
            ps.setTimestamp(5, Timestamp.valueOf(u.getFechaRegistro()));
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) u.setId(rs.getLong(1));
            }
            return u;
        }
    }

    @Override
    public Usuario leer(Long id) throws Exception {
        String sql = """
            SELECT id, eliminado, username, email, activo, fecha_registro 
            FROM usuario 
            WHERE id = ? AND eliminado = FALSE
        """;

        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId(rs.getLong("id"));
                    u.setEliminado(rs.getBoolean("eliminado"));
                    u.setUsername(rs.getString("username"));
                    u.setEmail(rs.getString("email"));
                    u.setActivo(rs.getBoolean("activo"));
                    Timestamp ts = rs.getTimestamp("fecha_registro");
                    if (ts != null) u.setFechaRegistro(ts.toLocalDateTime());
                    return u;
                }
            }
            return null;
        }
    }

    @Override
    public List<Usuario> leerTodos() throws Exception {
        String sql = """
            SELECT id, eliminado, username, email, activo, fecha_registro 
            FROM usuario 
            WHERE eliminado = FALSE
        """;

        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            List<Usuario> list = new ArrayList<>();

            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getLong("id"));
                u.setEliminado(rs.getBoolean("eliminado"));
                u.setUsername(rs.getString("username"));
                u.setEmail(rs.getString("email"));
                u.setActivo(rs.getBoolean("activo"));
                Timestamp ts = rs.getTimestamp("fecha_registro");
                if (ts != null) u.setFechaRegistro(ts.toLocalDateTime());
                list.add(u);
            }
            return list;
        }
    }

    @Override
    public Usuario actualizar(Usuario u) throws Exception {
        String sql = """
            UPDATE usuario 
            SET eliminado = ?, username = ?, email = ?, activo = ?, fecha_registro = ? 
            WHERE id = ?
        """;

        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBoolean(1, u.isEliminado());
            ps.setString(2, u.getUsername());
            ps.setString(3, u.getEmail());
            ps.setBoolean(4, u.isActivo());
            ps.setTimestamp(5, Timestamp.valueOf(u.getFechaRegistro()));
            ps.setLong(6, u.getId());
            ps.executeUpdate();
            return u;
        }
    }

    @Override
    public boolean eliminar(Long id) throws Exception {
        String sql = "UPDATE usuario SET eliminado = TRUE WHERE id = ?";
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // Búsquedas útiles
    public Usuario leerPorUsername(String username) throws Exception {
        String sql = "SELECT id FROM usuario WHERE username = ? AND eliminado = FALSE";
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return leer(rs.getLong("id"));
                return null;
            }
        }
    }

    public Usuario leerPorEmail(String email) throws Exception {
        String sql = "SELECT id FROM usuario WHERE email = ? AND eliminado = FALSE";
        try (Connection conn = getConn();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return leer(rs.getLong("id"));
                return null;
            }
        }
    }
}
